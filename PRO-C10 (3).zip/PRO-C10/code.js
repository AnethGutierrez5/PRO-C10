var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c7aec66d-bfb8-429a-96e5-0031ead8cb7e","d9d43649-141e-477a-8b74-31b1db24a323","18cd4c41-e304-428d-a9bd-242213deccb9","96c0d60f-39b7-40a8-901c-db40cb1e9a13"],"propsByKey":{"c7aec66d-bfb8-429a-96e5-0031ead8cb7e":{"name":"baseball_1","sourceUrl":"assets/api/v1/animation-library/gamelab/uoZwcPJapKhZIATHFDR107Ylx1bV1j8k/category_sports/baseball.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"uoZwcPJapKhZIATHFDR107Ylx1bV1j8k","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uoZwcPJapKhZIATHFDR107Ylx1bV1j8k/category_sports/baseball.png"},"d9d43649-141e-477a-8b74-31b1db24a323":{"name":"abstract_15_1","sourceUrl":"assets/api/v1/animation-library/gamelab/kpGIKirow4l3xRdN_BYD7pW3aVlfysex/category_backgrounds/abstract_15.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"kpGIKirow4l3xRdN_BYD7pW3aVlfysex","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/kpGIKirow4l3xRdN_BYD7pW3aVlfysex/category_backgrounds/abstract_15.png"},"18cd4c41-e304-428d-a9bd-242213deccb9":{"name":"abstract_16_1","sourceUrl":"assets/api/v1/animation-library/gamelab/OEa2gEbbvs2v84AZcjbUfOw_7tVqVKJr/category_backgrounds/abstract_16.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"OEa2gEbbvs2v84AZcjbUfOw_7tVqVKJr","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OEa2gEbbvs2v84AZcjbUfOw_7tVqVKJr/category_backgrounds/abstract_16.png"},"96c0d60f-39b7-40a8-901c-db40cb1e9a13":{"name":"court_1","sourceUrl":"assets/api/v1/animation-library/gamelab/T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV/category_backgrounds/background_court.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/T.BLfNn.3XTblWtBQ7GC1tSx4_8IsEJV/category_backgrounds/background_court.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//crear paddle y ball - paleta y pelota
var paddle = createSprite(200, 375, 70, 15);
paddle.shapeColor = "white";
var ball = createSprite(150, 250, 20, 20);
ball.setAnimation("baseball_1");
ball.scale = 0.06;
var score = 0;
var gameState = "serve";
//primera fila de cajas
var box1 = createSprite(25, 75, 50, 50);
box1.shapeColor = "pink";
box1.setAnimation("abstract_15_1");
box1.scale = 0.125;

var box2 = createSprite(75, 75, 50, 50);
box2.shapeColor="purple";
box2.setAnimation("abstract_16_1");
box2.scale = 0.125;
var box3 = createSprite(125, 75, 50, 50);
box3.shapeColor="pink";
box3.setAnimation("abstract_15_1");
box3.scale = 0.125;
var box4 = createSprite(175, 75, 50, 50);
box4.shapeColor="purple";
box4.setAnimation("abstract_16_1");
box4.scale = 0.125;
var box5 = createSprite(225, 75, 50, 50);
box5.shapeColor="pink";
box5.setAnimation("abstract_15_1");
box5.scale = 0.125;
var box6 = createSprite(275, 75, 50, 50);
box6.shapeColor="purple";
box6.setAnimation("abstract_16_1");
box6.scale = 0.125;
var box7 = createSprite(325, 75, 50, 50);
box7.shapeColor="pink";
box7.setAnimation("abstract_15_1");
box7.scale = 0.125;
var box8 = createSprite(375, 75, 50, 50);
box8.shapeColor="purple";
box8.setAnimation("abstract_16_1");
box8.scale = 0.125;

//segunda fila de cajas
var box9 = createSprite(25, 125, 50, 50);
box9.shapeColor="purple";
box9.setAnimation("abstract_16_1");
box9.scale = 0.125;
var box10 = createSprite(75, 125, 50, 50);
box10.shapeColor="pink";
box10.setAnimation("abstract_15_1");
box10.scale = 0.125;
var box11 = createSprite(125, 125, 50, 50);
box11.shapeColor="purple";
box11.setAnimation("abstract_16_1");
box11.scale = 0.125;
var box12 = createSprite(175, 125, 50, 50);
box12.shapeColor="pink";
box12.setAnimation("abstract_15_1");
box12.scale = 0.125;
var box13 = createSprite(225, 125, 50, 50);
box13.shapeColor="purple";
box13.setAnimation("abstract_16_1");
box13.scale = 0.125;
var box14 = createSprite(275, 125, 50, 50);
box14.shapeColor="pink";
box14.setAnimation("abstract_15_1");
box14.scale = 0.125;
var box15 = createSprite(325, 125, 50, 50);
box15.shapeColor="purple";
box15.setAnimation("abstract_16_1");
box15.scale = 0.125;
var box16 = createSprite(375, 125, 50, 50);
box16.shapeColor="pink";
box16.setAnimation("abstract_15_1");
box16.scale = 0.125;


function draw() {
  background("black");
  fill("white");
  textSize(20);
  text("PUNTUACION: " + score, 200, 20);
  if (gameState=="serve") {
    text("Presiona enter para comenzar", 100, 200);
    if(keyDown("space")){
      ball.velocityX = 3;
      ball.velocityY = 4;
      gameState = "play";
    }
  }
  if (gameState=="play") {
    gameState = "end";
  }
  if (gameState=="end") {
    if (score==16 || ball.isTouching(bottomEdge)) {
      ball.velocityX = 0;
      ball.velocityY = 0;
      text("Fin del juego", 200, 200);
    }
  }
  paddle.x = World.mouseX;
  
  //Mover la pelota al presionar la tecla enter
  
  //Hacer que la pelota rebote en la paleta y en tres lados del lienzo
  createEdgeSprites();
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(topEdge);
  ball.bounceOff(paddle);

  //Mover la paleta con el mouse a lo largo del eje x
  
  //destruir las cajas cuando la pelota las toque
  if(ball.isTouching(box1))
  {
    box1.destroy();
    score = score+1;
  }
  if (ball.isTouching(box2)) {
    box2.destroy();
    score = score+1;
  }
  if (ball.isTouching(box3)) {
    box3.destroy();
    score = score+1;
  }
  if (ball.isTouching(box4)) {
    box4.destroy();
    score = score+1;
  }
  if (ball.isTouching(box5)) {
    box5.destroy();
    score = score+1;
  }
  if (ball.isTouching(box6)) {
    box6.destroy();
    score = score+1;
  }
  if (ball.isTouching(box7)) {
    box7.destroy();
    score = score+1;
  }
  if (ball.isTouching(box8)) {
    box8.destroy();
    score = score+1;
  }
  if (ball.isTouching(box9)) {
    box9.destroy();
    score = score+1;
  }
  if (ball.isTouching(box10)) {
    box10.destroy();
    score = score+1;
  }
  if (ball.isTouching(box11)) {
    box11.destroy();
    score = score+1;
  }
  if (ball.isTouching(box12)) {
    box12.destroy();
    score = score+1;
  }
  if (ball.isTouching(box13)) {
    box13.destroy();
    score = score+1;
  }
  if (ball.isTouching(box14)) {
    box14.destroy();
    score = score+1;
  }
  if (ball.isTouching(box15)) {
    box15.destroy();
    score = score+1;
  }
  if (ball.isTouching(box16)) {
    box16.destroy();
    score = score+1;
  }
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
